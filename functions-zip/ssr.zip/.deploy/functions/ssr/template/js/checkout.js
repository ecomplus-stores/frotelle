import './custom-js/global'
import '#template/js/checkout'
import './custom-js/checkout'
