# Widget Martan

Storefront plugin for Martan reviews widgets

```js
import widgetMartan from '@ecomplus/widget-martan'

widgetMartan({
  martanStoreId: 123
})
```
